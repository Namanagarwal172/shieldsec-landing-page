import Head from 'next/head';

export default function Home() {
  return (
    <div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen">
      <Head>
        <title>ShieldSec - Cybersecurity for SMEs</title>
      </Head>

      {/* Header */}
      <header className="p-4 flex justify-between items-center shadow-md bg-white dark:bg-gray-800">
        <h1 className="text-2xl font-bold">ShieldSec</h1>
        <nav className="space-x-4">
          <a href="#" className="hover:underline">Home</a>
          <a href="#" className="hover:underline">Services</a>
          <a href="#" className="hover:underline">Pricing</a>
          <a href="#" className="hover:underline">Blog</a>
          <a href="#" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Free Scan</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20 px-4">
        <h2 className="text-4xl md:text-5xl font-extrabold mb-4">Affordable Cybersecurity for SMEs</h2>
        <p className="text-lg mb-6 max-w-2xl mx-auto">Scan, secure, and stay compliant – all in one platform.</p>
        <button className="px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700">Start Free Trial</button>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { title: 'Automated Scans' },
            { title: 'Risk Reports' },
            { title: 'CI/CD Integration' },
            { title: 'Compliance Checks' },
          ].map((feature, index) => (
            <div key={index} className="text-center p-4 bg-white dark:bg-gray-700 rounded shadow">
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-sm">Lorem ipsum dolor sit amet consectetur.</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="text-center py-16 px-4">
        <h3 className="text-3xl font-bold mb-4">Get started with ShieldSec today</h3>
        <button className="px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700">Try It Free</button>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 dark:bg-gray-800 text-center py-6">
        <p>© {new Date().getFullYear()} ShieldSec. All rights reserved.</p>
      </footer>
    </div>
  );
}